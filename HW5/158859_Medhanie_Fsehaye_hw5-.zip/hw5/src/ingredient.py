from __future__ import annotations


class Ingredient:
    def __init__(self, name: str, quantity: int, unit: str, reorder_level: int) -> None:
        self.__name = name
        self.__quantity = quantity
        self.__unit = unit
        self.__reorder_level = reorder_level

    def __eq__(self, value: object) -> bool:
        if isinstance(value, Ingredient):
            return self.__name == value.__name
        return False

    def __str__(self) -> str:
        output = "Ingredient: "
        output += f"name={self.__name}, "
        output += f"quantity={self.__quantity}, "
        output += f"unit={self.__unit}, "
        output += f"reorder_level={self.__reorder_level}"
        return output

    @property
    def name(self) -> str:
        return self.__name

    @property
    def quantity(self) -> int:
        return self.__quantity

    @quantity.setter
    def quantity(self, quantity: int) -> None:
        self.__quantity = quantity

    @property
    def unit(self) -> str:
        return self.__unit

    @unit.setter
    def unit(self, unit: str) -> None:
        self.__unit = unit

    @property
    def reorder_level(self) -> int:
        return self.__reorder_level

    @reorder_level.setter
    def reorder_level(self, reorder_level: int) -> None:
        self.__reorder_level = reorder_level

    @staticmethod
    def from_list_str(row: list[str]) -> Ingredient:
        return Ingredient(row[0], int(row[1]), row[2], int(row[3]))

    def to_list_str(self) -> list[str]:
        return [self.__name, str(self.__quantity), self.__unit, str(self.__reorder_level)]
