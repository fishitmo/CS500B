import csv

from recipe import PizzaRecipe

RECIPES_DATA_FILE = "recipes.csv"


class PizzaRecipeRepository:
    def __init__(self, filename: str = RECIPES_DATA_FILE) -> None:
        self.__filename = filename

    def load_recipes(self) -> list[PizzaRecipe]:
        recipes = []
        try:
            with open(self.__filename, newline="") as file:
                reader = csv.reader(file, delimiter=";")
                for row in reader:
                    if row:
                        recipes.append(PizzaRecipe.from_list_str(row))
        except FileNotFoundError:
            pass
        return recipes

    def save_recipes(self, recipes: list[PizzaRecipe]) -> None:
        with open(self.__filename, "w", newline="") as file:
            writer = csv.writer(file, delimiter=";")
            for recipe in recipes:
                writer.writerow(recipe.to_list_str())


if __name__ == "__main__":
    repo = PizzaRecipeRepository()
    recipes = repo.load_recipes()
    for recipe in recipes:
        print(recipe)
