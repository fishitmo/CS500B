from ingredient import Ingredient
from ingredient_repository import IngredientRepository


class InventoryManager:
    def __init__(self) -> None:
        self.__ingredients: dict[str, Ingredient] = {}

        self.__load_data()

    def __load_data(self) -> None:
        ingredient_repo = IngredientRepository()
        ingredients = ingredient_repo.load_ingredients()
        for ingredient in ingredients:
            self.__ingredients[ingredient.name] = ingredient

    def __save_data(self) -> None:
        ingredient_repo = IngredientRepository()
        ingredient_repo.save_ingredients(list(self.__ingredients.values()))

    def add_ingredient(self, name: str, quantity: int) -> None:
        if name in self.__ingredients:
            self.__ingredients[name].quantity += quantity
        else:
            self.__ingredients[name] = Ingredient(name, quantity, "", 0)
        self.__save_data()

    def remove_ingredient(self, name: str, quantity: int) -> bool:
        if name not in self.__ingredients:
            return False

        self.__ingredients[name].quantity -= quantity
        self.__save_data()
        return True

    def use_ingredient(self, recipe: dict[str, int]) -> None:
        for name, quantity in recipe.items():
            self.remove_ingredient(name, quantity)

    def check_reorder_levels(self) -> list[Ingredient]:
        result = []
        for name, ingredient in self.__ingredients.items():
            if ingredient.quantity <= ingredient.reorder_level:
                result.append(ingredient)
        return result

    def print_inventory(self) -> None:
        print("Inventory:")
        for ingredient in self.__ingredients.values():
            print(f" - {ingredient}")

    def get_ingredient(self, name: str) -> Ingredient | None:
        return self.__ingredients.get(name)
