import csv

from ingredient import Ingredient

INGREDIENTS_DATA_FILE = "ingredients.csv"


class IngredientRepository:
    def __init__(self, filename: str = INGREDIENTS_DATA_FILE) -> None:
        self.__filename = filename

    def load_ingredients(self) -> list[Ingredient]:
        buyers = []
        try:
            with open(self.__filename, newline="") as file:
                reader = csv.reader(file, delimiter=";")
                for row in reader:
                    if row:
                        buyer = Ingredient.from_list_str(row)
                        buyers.append(buyer)
        except FileNotFoundError:
            pass
        return buyers

    def save_ingredients(self, buyers: list[Ingredient]) -> None:
        with open(self.__filename, "w", newline="") as file:
            writer = csv.writer(file, delimiter=";")
            for buyer in buyers:
                writer.writerow(buyer.to_list_str())


if __name__ == "__main__":
    ingredient_repo = IngredientRepository()
    ingredients_list = ingredient_repo.load_ingredients()
    for ingredient in ingredients_list:
        print(ingredient)
