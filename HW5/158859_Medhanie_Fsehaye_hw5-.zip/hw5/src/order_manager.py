from inventory_manager import InventoryManager
from menu import PizzaCategory, PizzaMenuItem, PizzaSize, SideMenuItem
from order import Order
from recipe_management import RecipeManagement

CUSTOM_PIZZA_BASE_PRICE = 14.0
EACH_ITEM_ADDITIONAL_PRICE = 1.75
CUSTOM_PIZZA_BASE_ITEMS = {
    "Dough": 1,
    "Tomato Sauce": 150,
    "Mozzarella": 200,
}
CUSTOM_PIZZA_EXTRA_ITEMS = [
    "Pepperoni",
    "Mozzarella",
    "Ham",
    "Bacon",
    "Mushrooms",
    "Red Onion",
    "Olives",
    "Tomato",
    "Pineapple",
]


class OrderManager:
    def __init__(self, inventory_mgr: InventoryManager, recipe_mgt: RecipeManagement):
        self.__orders: list[Order] = []
        self.__inventory_mgr = inventory_mgr
        self.__recipe_mgt = recipe_mgt
        self.__order_counter = 1

    def create_order(self, customer_name: str) -> Order:
        order = Order(self.__order_counter, customer_name)
        return order

    def add_pizza_to_order(self, order: Order, pizza_item: PizzaMenuItem) -> None:
        recipe = self.__recipe_mgt.get_recipe_by_name(pizza_item.recipe_name)
        if recipe is not None:
            order.add_item(pizza_item)
            order.add_ingredients(recipe.ingredients)
        else:
            print("Recipe not found for this pizza.")

    def add_custom_pizza(self, order: Order, items: dict[str, int]) -> None:
        price = CUSTOM_PIZZA_BASE_PRICE
        ingredients: dict[str, int] = {}

        for ing, ing_qty in CUSTOM_PIZZA_BASE_ITEMS.items():
            if ing in ingredients:
                ingredients[ing] += ing_qty
            else:
                ingredients[ing] = ing_qty

        for item, qty in items.items():
            ing = self.__inventory_mgr.get_ingredient(item)
            if ing.unit in ['balls', 'cans']:
                ing_qty = 1
            else:
                ing_qty = 50
            if item in ingredients:
                ingredients[item] += ing_qty
            else:
                ingredients[item] = ing_qty
            price += qty * EACH_ITEM_ADDITIONAL_PRICE

        name = f"Custom Pizza ({len(items)} items)"
        desc = f"Custom pizza with {', '.join(ingredients.keys())}"
        custom_pizza = PizzaMenuItem(name, desc, price, PizzaSize.LARGE, PizzaCategory.CUSTOM)

        order.add_item(custom_pizza)
        order.add_ingredients(ingredients)

    def add_side_to_order(self, order: Order, side: SideMenuItem) -> None:
        order.add_item(side)
        order.add_ingredients({side.name: 1})

    def print_order_receipt(self, order: Order) -> None:
        order.print_receipt()

    def submit_order(self, order: Order) -> None:
        try:
            self.__inventory_mgr.use_ingredient(order.total_ingredients)
        except ValueError as e:
            print(f"Error submitting order: {e}")
            return
        self.__orders.append(order)
        print(f"Order #{order.order_id} submitted.")
        self.__order_counter += 1
