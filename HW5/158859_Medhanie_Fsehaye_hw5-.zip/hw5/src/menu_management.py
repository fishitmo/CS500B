from menu import MenuItem, PizzaCategory, PizzaMenuItem, SideCategory, SideMenuItem, PizzaSize
from menu_repository import MenuRepository


class MenuManagement:
    def __init__(self) -> None:
        self.__menu_items: dict[str, MenuItem] = {}

        self.__load_data()

    def __load_data(self) -> None:
        repo = MenuRepository()
        items = repo.load_menu_items()
        for item in items:
            self.__menu_items[item.name] = item

    def __save_data(self) -> None:
        repo = MenuRepository()
        repo.save_menu_items(list(self.__menu_items.values()))

    def add_menu_item(self, item: MenuItem) -> bool:
        if item.name in self.__menu_items:
            return False
        self.__menu_items[item.name] = item
        self.__save_data()
        return True

    def remove_menu_item(self, name: str) -> bool:
        if name not in self.__menu_items:
            return False
        del self.__menu_items[name]
        self.__save_data()
        return True

    def update_menu_item(self, item: MenuItem) -> bool:
        if item.name not in self.__menu_items:
            return False
        self.__menu_items[item.name] = item
        self.__save_data()
        return True

    def get_pizza_by_category(self, pizza_category: PizzaCategory) -> list[PizzaMenuItem]:
        result = []
        for item in self.__menu_items.values():
            if isinstance(item, PizzaMenuItem) and item.category == pizza_category:
                result.append(item)
        return result

    def get_side_by_category(self, side_category: SideCategory) -> list[SideMenuItem]:
        result = []
        for item in self.__menu_items.values():
            if isinstance(item, SideMenuItem) and item.category == side_category:
                result.append(item)
        return result

    def list_menu_items(self) -> list[MenuItem]:
        return list(self.__menu_items.values())

    def get_pizzas(self) -> list[PizzaMenuItem]:
        result = []
        for item in self.__menu_items.values():
            if isinstance(item, PizzaMenuItem):
                result.append(item)
        return result

    def get_sides(self) -> list[SideMenuItem]:
        result = []
        for item in self.__menu_items.values():
            if isinstance(item, SideMenuItem):
                result.append(item)
        return result
