import csv

from menu import MenuItem, PizzaMenuItem, SideMenuItem

MENU_DATA_FILE = "menu.csv"


class MenuRepository:
    def __init__(self, filename: str = MENU_DATA_FILE) -> None:
        self.__filename = filename

    def load_menu_items(self) -> list[MenuItem]:
        items = []
        try:
            with open(self.__filename, newline="") as file:
                reader = csv.reader(file, delimiter=";")
                for row in reader:
                    if not row:
                        continue
                    if row[0] == 'pizza':
                        items.append(PizzaMenuItem.from_list_str(row))
                    elif row[0] == 'side':
                        items.append(SideMenuItem.from_list_str(row))
        except FileNotFoundError:
            pass
        return items

    def save_menu_items(self, items: list[MenuItem]) -> None:
        with open(self.__filename, "w", newline="") as file:
            writer = csv.writer(file, delimiter=";")
            for item in items:
                # Polymorphic call to to_list_str()
                if isinstance(item, PizzaMenuItem) or isinstance(item, SideMenuItem):
                    writer.writerow(item.to_list_str())


if __name__ == "__main__":
    repo = MenuRepository()
    items = repo.load_menu_items()
    for item in items:
        print(item)
