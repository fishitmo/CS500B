from inventory_manager import InventoryManager
from menu_management import MenuManagement, PizzaCategory, PizzaMenuItem, PizzaSize, SideCategory, SideMenuItem
from order_manager import CUSTOM_PIZZA_BASE_PRICE, CUSTOM_PIZZA_EXTRA_ITEMS, EACH_ITEM_ADDITIONAL_PRICE, OrderManager
from recipe_management import PizzaRecipe, RecipeManagement


class PizzaStoreApp:
    def __init__(self) -> None:
        self.__inventory_mgr = InventoryManager()
        self.__recipe_mgt = RecipeManagement()
        self.__menu_mgt = MenuManagement()
        self.__order_mgr = OrderManager(self.__inventory_mgr, self.__recipe_mgt)

    def show_main_menu(self) -> None:
        while True:
            print("\n=== PIZZA STORE MANAGEMENT SYSTEM ===")
            print("1. New Order")
            print("2. Menu Management")
            print("3. Inventory Management")
            print("4. Recipe Management")
            print("0. Exit")

            choice = input("Enter your choice: ").strip()

            if choice == '1':
                self.__order_ui()
            elif choice == '2':
                self.__menu_ui()
            elif choice == '3':
                self.__inventory_ui()
            elif choice == '4':
                self.__recipe_ui()
            elif choice == '0':
                print("Bye")
                break
            else:
                print("Invalid choice.")

    # --- Order Processing ---
    def __order_ui(self) -> None:
        name = input("Enter Customer Name: ")
        order = self.__order_mgr.create_order(name)

        while True:
            print(f"\n--- Order: #{order.order_id} | Customer: {name} ---")
            print("1. Add standard pizza")
            print("2. Add custom pizza")
            print("3. Add side dish")
            print("4. Show receipt")
            print("5. Submit order")
            print("0. Cancel order & Back to main menu")

            choice = input("Enter your choice: ").strip()
            if choice == '1':
                self.__add_standard_pizza_ui(order)
            elif choice == '2':
                self.__add_custom_pizza_ui(order)
            elif choice == '3':
                self.__add_side_dish_ui(order)
            elif choice == '4':
                self.__order_mgr.print_order_receipt(order)
            elif choice == '5':
                self.__order_mgr.submit_order(order)
                break
            elif choice == '0':
                print("Order cancelled")
                break
            else:
                print("Invalid choice.")

    def __add_standard_pizza_ui(self, order) -> None:
        pizzas = self.__menu_mgt.get_pizzas()
        print("\nAvailable Pizzas:")
        for idx, p in enumerate(pizzas):
            print(f"{idx+1}. {p.name} ({p.size.value}) - ${p.price:.2f}")

        try:
            choice = int(input("Select Pizza #: ").strip()) - 1
            if 0 <= choice < len(pizzas):
                self.__order_mgr.add_pizza_to_order(order, pizzas[choice])
                print("Pizza added.")
            else:
                print("Invalid selection.")
        except ValueError:
            print("Invalid input.")

    def __add_custom_pizza_ui(self, order) -> None:
        print("\n--- Build Your Own Pizza ---")
        print("All start with Tomato Sauce and Mozzarella.")
        print(f"Base price: ${CUSTOM_PIZZA_BASE_PRICE:.2f} | Additional price per item: ${EACH_ITEM_ADDITIONAL_PRICE:.2f}")
        items: dict[str, int] = {}

        while True:
            print("Available options:")
            for idx, item in enumerate(CUSTOM_PIZZA_EXTRA_ITEMS):
                print(f"{idx+1}. {item}")
            print("0. Done Adding")

            try:
                choice = int(input("Select option: "))
                if choice == 0:
                    break
                if 0 < choice <= len(CUSTOM_PIZZA_EXTRA_ITEMS):
                    qty = int(input("Quantity: "))
                    if qty <= 0:
                        print("Quantity must be greater than 0.")
                        continue
                    item = CUSTOM_PIZZA_EXTRA_ITEMS[choice - 1]
                    if item in items:
                        items[item] += qty
                    else:
                        items[item] = qty
                    print(f"Added {item} (x {qty})")
                else:
                    print("Invalid selection.")
            except ValueError:
                pass

        self.__order_mgr.add_custom_pizza(order, items)
        print("Custom Pizza added.")

    def __add_side_dish_ui(self, order) -> None:
        sides = self.__menu_mgt.get_sides()
        print("\nAvailable Sides:")
        for idx, s in enumerate(sides):
            print(f"{idx+1}. {s.name} - ${s.price:.2f}")

        try:
            choice = int(input("Select Side: ")) - 1
            if 0 <= choice < len(sides):
                self.__order_mgr.add_side_to_order(order, sides[choice])
                print("Side added.")
            else:
                print("Invalid selection.")
        except ValueError:
            print("Invalid input.")

    # --- Menu Management ---
    def __menu_ui(self):
        while True:
            print()
            print("--- Menu Management ---")
            print("1. Show all menu items")
            print("2. Add new menu item")
            print("3. Remove menu item")
            print("0. Back to main menu")
            choice = input("Enter your choice: ").strip()

            if choice == '1':
                self.__show_menu_items_ui()
            elif choice == '2':
                self.__add_menu_item_ui()
            elif choice == '3':
                self.__remove_menu_item_ui()
            elif choice == '0':
                break
            else:
                print("Invalid choice.")

    def __show_menu_items_ui(self):
        print()
        print("\n--- Standard Menu ---")
        print("Pizzas:")
        for p in self.__menu_mgt.get_pizzas():
            print(f"- {p}")
        print("\nSides:")
        for s in self.__menu_mgt.get_sides():
            print(f"- {s}")

    def __add_menu_item_ui(self):
        print()
        print("\n--- Add Menu Item ---")
        choice = input("1. Pizza\n2. Side\nEnter your choice: ").strip()
        if choice == '1':
            name = input("Enter pizza name: ").strip()
            desc = input("Enter description: ").strip()
            price = float(input("Enter price: ").strip())
            size = PizzaSize(input("Enter size (Small, Medium, Large, Extra Large): ").strip())
            category = PizzaCategory(input("Enter category (Vegetarian, Meat Lovers, Specialty, Custom): ").strip())
            recipe = input("Enter recipe name (leave blank if not applicable): ").strip()
            if not recipe:
                recipe = None
            success = self.__menu_mgt.add_menu_item(PizzaMenuItem(name, desc, price, size, category))
            if success:
                print("Pizza menu item added.")
            else:
                print("Error: Pizza with this name already exists.")
        elif choice == '2':
            name = input("Enter side name: ").strip()
            desc = input("Enter description: ").strip()
            price = float(input("Enter price: ").strip())
            category = SideCategory(input("Enter category (Appetizer, Entree, Dessert): ").strip())
            success = self.__menu_mgt.add_menu_item(SideMenuItem(name, desc, price, category))
            if success:
                print("Side menu item added.")
            else:
                print("Error: Side with this name already exists.")
        else:
            print("Invalid choice.")

    def __remove_menu_item_ui(self):
        print()
        print("\n--- Remove Menu Item ---")
        name = input("Enter menu item name: ").strip()
        success = self.__menu_mgt.remove_menu_item(name)
        if success:
            print("Menu item removed.")
        else:
            print("Error: Menu item not found.")

    # --- Inventory Management ---
    def __inventory_ui(self):
        while True:
            print()
            print("\n--- Inventory Management ---")
            print("1. Show all ingredients")
            print("2. Check low stock ingredients")
            print("3. Add stock ingredients")
            print("0. Back to main menu")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.__show_inventory_ui()
            elif choice == '2':
                self.__check_low_stock_ui()
            elif choice == '3':
                self.__add_stock_ui()
            elif choice == '0':
                break

    def __show_inventory_ui(self):
        print()
        print("\n--- Inventory ---")
        self.__inventory_mgr.print_inventory()

    def __check_low_stock_ui(self):
        low_stock = self.__inventory_mgr.check_reorder_levels()
        if not low_stock:
            print("No low stock items.")
        else:
            print("Low stock:")
            for ing in low_stock:
                print(f"- {ing.name}: {ing.quantity} {ing.unit} left (Reorder Level: {ing.reorder_level})")

    def __add_stock_ui(self):
        name = input("Ingredient name: ")
        qty = int(input("Quantity to add: "))
        self.__inventory_mgr.add_ingredient(name, qty)
        print(f"{qty} {name} added to inventory.")

    # --- Recipe Management ---
    def __recipe_ui(self):
        while True:
            print()
            print("\n--- Recipe Management ---")
            print("1. View all recipes")
            print("2. Add new recipe")
            print("3. Remove recipe")
            print("0. Back to main menu")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.__show_recipes_ui()
            elif choice == '2':
                self.__add_recipe_ui()
            elif choice == '3':
                self.__remove_recipe_ui()
            elif choice == '0':
                break

    def __show_recipes_ui(self):
        print()
        print("\n--- Recipes ---")
        recipes = self.__recipe_mgt.list_recipes()
        for r in recipes:
            print(f"{r.name}: {r.ingredients}")

    def __add_recipe_ui(self):
        print()
        print("\n--- Add Recipe ---")
        name = input("Recipe name: ")
        ingredients = {}
        while True:
            ing_name = input("Ingredient name (leave blank to finish): ").strip()
            if not ing_name:
                break
            ing_qty = int(input("Quantity: "))
            ingredients[ing_name] = ing_qty

        success = self.__recipe_mgt.add_recipe(PizzaRecipe(name, ingredients))
        if success:
            print("Recipe added.")
        else:
            print("Error: Recipe with this name already exists.")

    def __remove_recipe_ui(self):
        print()
        print("\n--- Remove Recipe ---")
        name = input("Recipe name: ")

        sucess = self.__recipe_mgt.remove_recipe(name)
        if sucess:
            print("Recipe removed.")
        else:
            print("Error: Recipe not found.")


if __name__ == "__main__":
    app = PizzaStoreApp()
    app.show_main_menu()
