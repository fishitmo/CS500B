from __future__ import annotations

from enum import Enum


class PizzaSize(Enum):
    SMALL = "Small"
    MEDIUM = "Medium"
    LARGE = "Large"
    EXTRA_LARGE = "Extra Large"


class PizzaCategory(Enum):
    VEGETARIAN = "Vegetarian"
    MEAT_LOVERS = "Meat Lovers"
    SPECIALTY = "Specialty"
    CUSTOM = "Custom"


class SideCategory(Enum):
    APPETIZER = "Appetizer"
    DESSERT = "Dessert"
    BEVERAGE = "Beverage"


class MenuItem:
    def __init__(self, name: str, description: str, price: float) -> None:
        self.__name = name
        self.__description = description
        self.__price = price

    def __eq__(self, value: object) -> bool:
        if isinstance(value, MenuItem):
            return self.__name == value.__name and self.price == value.price
        return False

    def __str__(self) -> str:
        name = f"{self.__name}"
        price = f"${self.__price:.2f}"
        output = f"{name:.<60}" + f"{price:>6}"
        output += f"\n    {self.__description}"
        return output

    @property
    def name(self) -> str:
        return self.__name

    @property
    def description(self) -> str:
        return self.__description

    @property
    def price(self) -> float:
        return self.__price

    @price.setter
    def price(self, value: float) -> None:
        self.__price = value


class PizzaMenuItem(MenuItem):
    def __init__(self, name: str, description: str, price: float, size: PizzaSize, category: PizzaCategory, recipe_name: str | None = None) -> None:
        super().__init__(name, description, price)
        self.__size = size
        self.__category = category
        self.__recipe_name = recipe_name

    @property
    def size(self) -> PizzaSize:
        return self.__size

    @property
    def category(self) -> PizzaCategory:
        return self.__category

    @property
    def recipe_name(self) -> str | None:
        return self.__recipe_name

    def to_list_str(self) -> list[str]:
        # Schema: type, name, description, price, size, category, recipe_name
        return ["pizza", self.name, self.description, str(self.price), self.__size.value, self.__category.value, self.__recipe_name if self.__recipe_name else ""]

    @staticmethod
    def from_list_str(row: list[str]) -> PizzaMenuItem:
        # row: [type, name, description, price, size, category, recipe_name]
        return PizzaMenuItem(row[1], row[2], float(row[3]), PizzaSize(row[4]), PizzaCategory(row[5]), row[6] if row[6] else None)


class SideMenuItem(MenuItem):
    def __init__(self, name: str, description: str, price: float, category: SideCategory) -> None:
        super().__init__(name, description, price)
        self.__category = category

    @property
    def category(self) -> SideCategory:
        return self.__category

    def to_list_str(self) -> list[str]:
        # Schema: type, name, description, price, category
        return ["side", self.name, self.description, str(self.price), self.__category.value]

    @staticmethod
    def from_list_str(row: list[str]) -> SideMenuItem:
        # row: [type, name, description, price, category, ...]
        return SideMenuItem(row[1], row[2], float(row[3]), SideCategory(row[4]))
