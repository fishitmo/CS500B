from recipe import PizzaRecipe
from recipe_repository import PizzaRecipeRepository


class RecipeManagement:
    def __init__(self) -> None:
        self.__recipes: dict[str, PizzaRecipe] = {}

        self.__load_data()

    def __load_data(self) -> None:
        repo = PizzaRecipeRepository()
        recipes = repo.load_recipes()
        for recipe in recipes:
            self.__recipes[recipe.name] = recipe

    def __save_data(self) -> None:
        repo = PizzaRecipeRepository()
        repo.save_recipes(list(self.__recipes.values()))

    def add_recipe(self, recipe: PizzaRecipe) -> bool:
        if recipe.name in self.__recipes:
            return False
        self.__recipes[recipe.name] = recipe
        self.__save_data()
        return True

    def remove_recipe(self, recipe_name: str) -> bool:
        if recipe_name not in self.__recipes:
            return False

        del self.__recipes[recipe_name]
        self.__save_data()
        return True

    def update_recipe(self, recipe_name: str, new_ingredients: dict[str, int]) -> bool:
        if recipe_name not in self.__recipes:
            return False

        self.__recipes[recipe_name].ingredients = new_ingredients
        self.__save_data()
        return True

    def get_recipe_by_name(self, name: str) -> PizzaRecipe | None:
        return self.__recipes.get(name)

    def list_recipes(self) -> list[PizzaRecipe]:
        return list(self.__recipes.values())
