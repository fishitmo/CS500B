from menu import MenuItem


class Order:
    def __init__(self, order_id: int, customer_name: str) -> None:
        self.__order_id = order_id
        self.__customer_name = customer_name
        self.__items: list[MenuItem] = []
        self.__total_ingredients: dict[str, int] = {}
        self.__total_price = 0.0

    def __str__(self) -> str:
        return f"Order id={self.__order_id}, customer={self.__customer_name}, items={self.__items}, total_price={self.__total_price}"

    def __eq__(self, value: object) -> bool:
        if isinstance(value, Order):
            return self.__order_id == value.__order_id
        return False

    @property
    def order_id(self) -> int:
        return self.__order_id

    @property
    def customer_name(self) -> str:
        return self.__customer_name

    @property
    def items(self) -> list[MenuItem]:
        return self.__items

    @property
    def total_ingredients(self) -> dict[str, int]:
        return self.__total_ingredients

    @property
    def total_price(self) -> float:
        return self.__total_price

    def add_item(self, item: MenuItem) -> None:
        self.__items.append(item)
        self.__total_price += item.price

    def add_ingredients(self, ingredients: dict[str, int]) -> None:
        for name, qty in ingredients.items():
            if name in self.__total_ingredients:
                self.__total_ingredients[name] += qty
            else:
                self.__total_ingredients[name] = qty

    def print_receipt(self) -> None:
        print("\n" + "=" * 50)
        print(f"ORDER SLIP #{self.__order_id}")
        print(f"Customer: {self.__customer_name}")
        print("-" * 50)
        total = 0.0
        for item in self.__items:
            price = f"${item.price:.2f}"
            print(f"{item.name:<40} {price:>9}")
            total += item.price
        print("-" * 50)
        total = f"${total:.2f}"
        print(f"TOTAL:{' ' * 35}{total:>9}")
        print("=" * 50 + "\n")
