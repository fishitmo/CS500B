from __future__ import annotations


class PizzaRecipe:
    def __init__(self, name: str, ingredients: dict[str, int]) -> None:
        self.__name = name
        self.__ingredients = ingredients

    def __eq__(self, value: object) -> bool:
        if isinstance(value, PizzaRecipe):
            return self.__name == value.__name
        return False

    def __str__(self) -> str:
        return f"Recipe: name={self.__name}, ingredients={self.__ingredients}"

    @property
    def name(self) -> str:
        return self.__name

    @property
    def ingredients(self) -> dict[str, int]:
        return self.__ingredients.copy()

    @ingredients.setter
    def ingredients(self, value: dict[str, int]) -> None:
        self.__ingredients = value

    def to_list_str(self) -> list[str]:
        # Serialize ingredients dict to string: "Item1:Qty1,Item2:Qty2"
        ing_str = ",".join([f"{k}:{v}" for k, v in self.__ingredients.items()])
        return [self.__name, ing_str]

    @staticmethod
    def from_list_str(row: list[str]) -> PizzaRecipe:
        # row: [name, ingredients_str]
        name = row[0]
        ing_str = row[1]

        ing_dict = {}
        if ing_str:
            items = ing_str.split(',')
            for item in items:
                k, v = item.split(':')
                ing_dict[k] = int(v)

        return PizzaRecipe(name, ing_dict)
