# Homework 5: Pizza Store Application


## Data Files
The application uses the following data files:
- `src/ingredients.csv`: A list of ingredients.
- `src/menu.csv`: A list of menu items.
- `src/recipes.csv`: A list of pizza recipes.

## Run the Application
To run the application, execute the following command:
```bash
python src/pizza_store.py
```
